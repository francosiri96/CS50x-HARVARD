
var d = new Date();
document.getElementById("demo").innerHTML = d;

var edad = prompt("Cual es tu edad?");
document.writeln("hola" + edad);