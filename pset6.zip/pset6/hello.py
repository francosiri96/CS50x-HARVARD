from cs50 import get_string

s = get_string("what your name?\n")
print("hello, " + s)
