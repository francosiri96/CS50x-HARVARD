#include <cs50.h> #include <stdio.h>
int main(void)
{
    int i=0, j=0, altura=0;
    printf("Hola! que altura quieres para la piramide?");
    scanf("%d",&altura);
    for( i=0;i<=altura;i++)
    {
        for(j=0;j<i;j++)
        {
            printf("# ");
        }
        printf("\n");
    }



    return 0;
}